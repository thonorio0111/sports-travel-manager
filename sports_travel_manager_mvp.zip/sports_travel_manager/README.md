# Sports Travel Manager — MVP 0.1

Primeira versão funcional de um gerenciador de logística esportiva, projetado para uso em celular.

## Recursos atuais
- Cadastro, edição e exclusão de equipes.
- Cadastro manual, edição e exclusão de jogos.
- Campos para esporte, categoria, cidade-base, estádio, data, horário local, adversário e notas.
- Calendário com filtros por equipe e período.
- Painel geral com contagem de equipes, jogos e cidades.
- Mapa geral com pontos de jogos e estádios principais, quando as coordenadas são fornecidas.
- Mapa/rota individual por equipe.
- Estimativa de distância em linha reta entre jogos consecutivos (Haversine).
- Links para consultar rotas rodoviárias reais no Google Maps.
- Armazenamento local no navegador.

## Limitações conhecidas
- O mapa precisa de internet (Leaflet + OpenStreetMap).
- Para localizar um estádio no mapa, informe latitude e longitude; esta versão não tem geocodificação automática.
- Distâncias calculadas pelo app são em linha reta, não rodoviárias.
- Dados ficam no dispositivo/navegador atual; não há login nem sincronização em nuvem.
- Ainda não é um APK Android assinado. É uma primeira versão web instalável (PWA); a próxima etapa pode empacotá-la para Android com Capacitor.
- Antes de uso real, convém adicionar exportação/importação de backup na interface, ícones e testes adicionais.

## Como testar
1. Descompacte a pasta.
2. Hospede os arquivos em HTTPS (por exemplo, GitHub Pages) ou rode um servidor local.
3. Abra `index.html` para testar os formulários; mapas e PWA exigem hospedagem/servidor em muitos navegadores.
4. No Android, abra o site hospedado no Chrome e use o menu ⋮ → “Instalar app” ou “Adicionar à tela inicial”.

## Próximas etapas sugeridas
1. Adicionar botões visíveis para exportar/importar backup.
2. Geocodificação opcional por OpenStreetMap/Nominatim, respeitando limites de uso.
3. Rotas rodoviárias e estimativas de tempo via provedor de rotas gratuito com limites.
4. Empacotamento Android com Capacitor e criação de APK de teste.
5. Testes de acessibilidade, persistência e validação de dados.
